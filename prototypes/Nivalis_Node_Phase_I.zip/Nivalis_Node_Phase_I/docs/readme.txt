Supporting documentation for Phase I.
