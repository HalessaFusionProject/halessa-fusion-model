Simulation results for Nivalis Node Phase I.
