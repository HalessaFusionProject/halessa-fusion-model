Micro Layer: Tuned resonance lattice modeling.
