Macro Layer: Shell suspension and waveform dampening scaffold.
